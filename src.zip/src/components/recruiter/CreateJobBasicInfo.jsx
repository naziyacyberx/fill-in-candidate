import React, { useEffect, useImperativeHandle, useState, forwardRef } from "react";
import { Card, Form, Button, Row, Col } from "react-bootstrap";
import GooglePlacesAutocomplete from "react-google-places-autocomplete";

const CreateJobBasicInfo = forwardRef(({ formData, setFormData }, ref) => {
  const [jobTitle, setJobTitle] = useState(formData.title || "");
  const [department, setDepartment] = useState(formData.department || "");
  const [location, setLocation] = useState(formData.address || null);
  const [employmentType, setEmploymentType] = useState(formData.employmentType || "");
  const [validated, setValidated] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const [lat, setLat] = useState("");
  const [lng, setLng] = useState("");
  const employmentOptions = ["Full Time", "Part Time", "Contract", "Internship"];

  useEffect(() => {
    setFormData((prev) => ({
      ...prev,
      title: jobTitle,
      department: department,
      address: location,
      employmentType: employmentType,
      latitude:lat,
      longitude:lng,
    }));
  }, [jobTitle, department, location, employmentType, setFormData, lat, lng]);

  const handleEmploymentClick = (type) => {
    setEmploymentType(type);
  };

  const handleSelect = (val) => {
    setLocation(val);
    setIsFocused(false);
    const placeId = val.value.place_id; // ✅ extract placeId correctly

       const service = new window.google.maps.places.PlacesService(
      document.createElement("div")
    );

    service.getDetails({ placeId }, (place, status) => {
      if (status === window.google.maps.places.PlacesServiceStatus.OK) {
        const latitude = place.geometry.location.lat();
        const longitude = place.geometry.location.lng();
        console.log("lat lng",latitude, longitude);
        
        setLat(latitude.toString());
        setLng(longitude.toString());
      } else {
        console.error("Place details fetch failed:", status);
      }
    });
  };

  // Expose validate method to parent
  useImperativeHandle(ref, () => ({
    validate: () => {
      setValidated(true);
      return jobTitle && department && location && employmentType;
    },
  }));

  return (
    <Card className="m-4 p-4 shadow-sm border border-primary-subtle">
      <h6 className="mb-3"><strong>Basic Information</strong></h6>
      <Form noValidate validated={validated}>
        <Form.Group className="mb-3">
          <Form.Label>Job Title</Form.Label>
          <Form.Control
            required
            type="text"
            value={jobTitle}
            onChange={(e) => setJobTitle(e.target.value)}
            placeholder="e.g. Dentist Expert"
          />
          <Form.Control.Feedback type="invalid">
            Job Title is required.
          </Form.Control.Feedback>
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label>Department</Form.Label>
          <Form.Select
            required
            value={department}
            onChange={(e) => setDepartment(e.target.value)}
          >
            <option value="">Select Department</option>
            <option value="Dentist">Dentist</option>
            <option value="Receptionist">Receptionist</option>
            <option value="Hygienist">Hygienist</option>
            <option value="Oral Health Therapist">Oral Health Therapist</option>
          </Form.Select>
          <Form.Control.Feedback type="invalid">
            Department is required.
          </Form.Control.Feedback>
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label>Location</Form.Label>
          <div className={validated && !location ? 'border border-danger rounded p-1' : ''}>
            <GooglePlacesAutocomplete
              apiKey={import.meta.env.VITE_GOOGLE_API_KEY}
              selectProps={{
                value: location,
                onChange: handleSelect,
                onFocus: () => setIsFocused(true),
                placeholder: "Enter Location",
                styles: {
                  control: (base) => ({
                    ...base,
                    borderRadius: "6px",
                    minHeight: "45px",
                    boxShadow: "none",
                    borderColor: validated && !location ? 'red' : base.borderColor,
                  }),
                },
              }}
              autocompletionRequest={{ types: ["(cities)"] }}
            />
          </div>
          {validated && !location && (
            <div className="text-danger mt-1">Location is required.</div>
          )}
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label>Employment Type</Form.Label>
          <Row>
            {employmentOptions.map((type, idx) => (
              <Col xs={6} sm={6} md={3} key={idx} className="mb-2">
                <Button
                  variant={
                    employmentType === type
                      ? type === "Full Time"
                        ? "primary"
                        : type === "Part Time"
                        ? "info"
                        : "dark"
                      : "outline-secondary"
                  }
                  onClick={() => handleEmploymentClick(type)}
                  className="w-100"
                >
                  {type}
                </Button>
              </Col>
            ))}
          </Row>
          {validated && !employmentType && (
            <div className="text-danger mt-1">Employment type is required.</div>
          )}
        </Form.Group>
      </Form>
    </Card>
  );
});

export default CreateJobBasicInfo;
